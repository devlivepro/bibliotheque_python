from django.db import models

class Media(models.Model):
    MEDIA_TYPES = [
        ('cd', 'CD'),
        ('dvd', 'DVD'),
        ('livre', 'Livre'),
        ('jeu', 'Jeu de plateau'),
    ]

    type = models.CharField(max_length=20, choices=MEDIA_TYPES)
    titre = models.CharField(max_length=255)
    auteur = models.CharField(max_length=255, blank=True, null=True)
    disponible = models.BooleanField(default=True)

    def __str__(self):
        return self.titre


class Livre(Media):
    nb_pages = models.IntegerField()

    def __str__(self):
        return f"{self.titre} - Livre"

class DVD(Media):
    duree_minutes = models.IntegerField()

    def __str__(self):
        return f"{self.titre} - DVD"

class CD(Media):
    duree_minutes = models.IntegerField(default=0)

    def __str__(self):
        return self.titre

class JeuDePlateau(models.Model):
    titre = models.CharField(max_length=100)
    createur = models.CharField(max_length=100)
    disponible = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.titre} - Jeu de plateau"


class Membre(models.Model):
    nom = models.CharField(max_length=100)
    nb_emprunts = models.IntegerField(default=0)
    bloque = models.BooleanField(default=False)

    def __str__(self):
        return self.nom