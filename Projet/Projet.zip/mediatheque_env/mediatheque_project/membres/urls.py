from django.urls import path
from . import views
from .views import MediaViews

urlpatterns = [
    path('', views.index2, name='index2'),
    path('consultation_medias/', MediaViews.consultation_medias, name='consultation_medias')
]
