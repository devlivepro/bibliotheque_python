from django.contrib import admin
from .models import Membre
from .models import Livre, DVD, CD, JeuDePlateau, Emprunt

admin.site.register(Livre)
admin.site.register(DVD)
admin.site.register(CD)
admin.site.register(JeuDePlateau)
admin.site.register(Emprunt)
admin.site.register(Membre)
