from django.db import models
from django.utils import timezone


class Media(models.Model):
    MEDIA_TYPES = [
        ('cd', 'CD'),
        ('dvd', 'DVD'),
        ('livre', 'Livre'),
        ('jeu', 'Jeu de plateau'),
    ]

    titre = models.CharField(max_length=255)
    auteur = models.CharField(max_length=255, blank=True, null=True)
    disponible = models.BooleanField(default=True)
    type = models.CharField(max_length=20, choices=MEDIA_TYPES)

    def __str__(self):
        return self.titre


class Livre(Media):
    nb_pages = models.IntegerField(blank=True, null=True)  # Champ non obligatoire

    def __str__(self):
        return f"{self.titre} - Livre"

class DVD(Media):
    duree_minutes = models.IntegerField()

    def __str__(self):
        return f"{self.titre} - DVD"

class CD(Media):
    duree_minutes = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.titre} - CD"

class JeuDePlateau(models.Model):
    titre = models.CharField(max_length=100)
    createur = models.CharField(max_length=100)
    disponible = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.titre} - Jeu de plateau"


class Membre(models.Model):
    nom = models.CharField(max_length=100)
    nb_emprunts = models.IntegerField(default=0)
    bloque = models.BooleanField(default=False)

    def __str__(self):
        return self.nom

class Emprunt(models.Model):
    membre = models.ForeignKey(Membre, on_delete=models.CASCADE)
    media = models.ForeignKey(Media, on_delete=models.CASCADE)
    date_emprunt = models.DateField(default=timezone.now)
    date_retour_prevue = models.DateField(default=timezone.now)  # Define your default value here
    est_rendu = models.BooleanField(default=False)  # Assurez-vous que ce champ est défini

    def __str__(self):
        return f"{self.membre.nom} - {self.media.titre}"

