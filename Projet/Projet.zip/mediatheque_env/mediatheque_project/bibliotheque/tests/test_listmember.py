# Fichier: test_views.py

from django.test import RequestFactory
from django.urls import reverse
from bibliotheque.views import MembreViews


def test_list_member_view_returns_200():
    # Créer une instance de RequestFactory pour simuler une requête GET vers la vue 'list_member'
    request = RequestFactory().get(reverse('list_member'))

    # Appeler la méthode de vue pour lister les membres avec la requête simulée
    response = MembreViews.list_member(request)

    # Vérifier si le statut de la réponse est 200 (OK)
    assert response.status_code == 200

    # Vérifier si le template 'bibliotheque/list_member.html' est utilisé dans la réponse
    templates_used = [template.name for template in response.templates]
    assert 'bibliotheque/list_member.html' in templates_used