# Fichier: test_views.py

from django.test import RequestFactory
from django.urls import reverse
from bibliotheque.models import Membre
from bibliotheque.views import MembreViews


def test_delete_member_view_returns_200():
    # Créer un membre pour le test
    membre = Membre.objects.create(nom='Jane Doe')

    # Créer une instance de RequestFactory pour simuler une requête POST vers la vue 'delete_membre'
    request = RequestFactory().post(reverse('delete_membre', args=[membre.id]))

    # Appeler la méthode de vue pour supprimer le membre avec la requête simulée
    response = MembreViews.delete_membre(request, membre.id)

    # Vérifier si le statut de la réponse est 302 (redirection après la suppression)
    assert response.status_code == 302

    # Vérifier si le membre a été supprimé de la base de données
    assert not Membre.objects.filter(id=membre.id).exists()
