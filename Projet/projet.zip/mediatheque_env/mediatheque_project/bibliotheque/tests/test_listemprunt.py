# Fichier: test_views.py

from django.test import RequestFactory
from django.urls import reverse
from bibliotheque.models import Emprunt
from bibliotheque.views import MediaViews


def test_list_emprunts_view_returns_200():
    # Créer un emprunt pour le test
    Emprunt.objects.create(membre_id=1, media_id=1)

    # Créer une instance de RequestFactory pour simuler une requête GET vers la vue 'list_emprunts'
    request = RequestFactory().get(reverse('list_emprunts'))

    # Appeler la méthode de vue pour lister les emprunts avec la requête simulée
    response = MediaViews.list_emprunts(request)

    # Vérifier si le statut de la réponse est 200 (OK)
    assert response.status_code == 200

    # Vérifier si le template 'bibliotheque/list_emprunts.html' est utilisé dans la réponse
    templates_used = [template.name for template in response.templates]
    assert 'bibliotheque/list_emprunts.html' in templates_used

    # Vérifier si le nombre d'emprunts dans la réponse correspond au nombre d'emprunts en base de données
    assert Emprunt.objects.count() == len(response.context['emprunts'])