# Fichier: test_createmember.py

from django.test import TestCase, RequestFactory
from django.urls import reverse
from bibliotheque.views import MembreViews


class TestCreateMemberView(TestCase):
    def test_create_member_view_returns_200(self):
        # Créer une instance de RequestFactory pour simuler une requête POST vers la vue 'create_member'
        url = reverse('create_member')
        data = {'nom': 'John Doe'}
        request = RequestFactory().post(url, data)

        # Appeler la méthode de vue pour créer un membre avec la requête simulée
        response = MembreViews.create_member(request)

        # Vérifier si le statut de la réponse est 200 (OK)
        self.assertEqual(response.status_code, 200)