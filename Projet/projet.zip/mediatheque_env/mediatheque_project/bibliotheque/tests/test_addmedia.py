# Fichier: test_views.py

from django.test import TestCase, RequestFactory
from django.urls import reverse
from bibliotheque.views import MediaViews


class TestAddMediaView(TestCase):
    def test_add_media_view_returns_200(self):
        # Créer une instance de RequestFactory pour simuler une requête POST vers la vue 'add_media'
        url = reverse('add_media')
        data = {
            'titre': 'Mon nouveau livre',
            'auteur': 'John Doe',
            'type': 'livre',
            'nb_pages': 200  # Champ spécifique au type de média (livre)
        }
        request = RequestFactory().post(url, data)

        # Appeler la méthode de vue pour ajouter un média avec la requête simulée
        response = MediaViews.add_media(request)

        # Vérifier si le statut de la réponse est 200 (OK)
        self.assertEqual(response.status_code, 200)
