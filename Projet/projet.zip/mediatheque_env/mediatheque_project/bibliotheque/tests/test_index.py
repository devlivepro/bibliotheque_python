# Fichier: test_index.py

from django.test import RequestFactory
from django.urls import reverse
from bibliotheque.views import index


def test_index_view_returns_200():
    # Créer une instance de RequestFactory pour simuler une requête GET vers la vue 'index'
    request = RequestFactory().get(reverse('index'))

    # Appeler la vue 'index' avec la requête simulée
    response = index(request)

    # Vérifier si le statut de la réponse est 200 (OK)
    assert response.status_code == 200