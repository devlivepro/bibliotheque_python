from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponseBadRequest, HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.views import View
from .forms import MediaForm, MembreForm, LivreForm, CDForm, DVDForm, JeuDePlateauForm
from .models import Media, Livre, CD, DVD, JeuDePlateau, Emprunt, Membre
from django.utils import timezone


def admin_required(view_func):
    actual_decorator = user_passes_test(
        lambda user: user.is_authenticated and user.is_staff,
        login_url='/admin/login/',  # Redirige vers l'écran de connexion admin
        redirect_field_name=None
    )
    return actual_decorator(view_func)

def home(request):
    return render(request, 'bibliotheque/home.html')

def index(request):
    return render(request, 'bibliotheque/index.html')

class MembreViews(View):
    @admin_required
    @staticmethod
    def create_member(request):
        if request.method == 'POST':
            form = MembreForm(request.POST)
            if form.is_valid():
                form.save()  # Le formulaire sauvegarde automatiquement le nouveau membres
                return redirect('list_member')
        else:
            form = MembreForm()
        return render(request, 'bibliotheque/create_member.html', {'form': form})

    @admin_required
    @staticmethod
    def list_member(request):
        membres = Membre.objects.all()
        return render(request, 'bibliotheque/list_member.html', {'membres': membres})

    @admin_required
    @staticmethod
    def update_member(request, membre_id):
        membre = get_object_or_404(Membre, pk=membre_id)
        if request.method == 'POST':
            membre.nom = request.POST.get('nom')
            membre.save()
            return redirect('list_member')
        return render(request, 'bibliotheque/update_member.html', {'membres': membre})

    @admin_required
    @staticmethod
    def delete_membre(request, membre_id):
        membre = get_object_or_404(Membre, pk=membre_id)
        if request.method == 'POST':
            membre.delete()
            return redirect('list_member')
        return redirect('list_member')

    @admin_required
    @staticmethod
    def confirm_delete_membre(request, membre_id):
        membre = get_object_or_404(Membre, pk=membre_id)
        return render(request, 'bibliotheque/delete_membre.html', {'membres': membre})


    @admin_required
    @staticmethod
    def detail_membre(request, membre_id):
        membre = get_object_or_404(Membre, pk=membre_id)
        medias_disponibles = membre.media_set.filter(disponible=True)
        return render(request, 'bibliotheque/list_medias.html', {'membres': membre, 'medias_disponibles': medias_disponibles})

    @admin_required
    def create_emprunt(request, membre_id):
        try:
            membre = get_object_or_404(Membre, pk=membre_id)

            if request.method == 'POST':
                media_id = request.POST.get('media_id')
                media = get_object_or_404(Media, pk=media_id, disponible=True)

                # Vérification des emprunts en retard du membres
                emprunt_en_retard = Emprunt.objects.filter(membre=membre,
                                                           date_retour_prevue__lt=timezone.now(),
                                                           est_rendu=False).exists()
                if emprunt_en_retard:
                    return HttpResponseBadRequest("Le membres a un emprunt en retard et ne peut pas emprunter.")

                # Création d'un nouvel emprunt avec date de retour prévue dans une semaine
                date_retour_prevue = timezone.now() + timezone.timedelta(days=7)
                emprunt = Emprunt.objects.create(membre=membre, media=media,
                                                 date_emprunt=timezone.now(),
                                                 date_retour_prevue=date_retour_prevue)

                # Mise à jour de l'état du média
                media.disponible = False
                media.save()

                return redirect('list_medias')

            medias_disponibles = Media.objects.filter(disponible=True)
            return render(request, 'bibliotheque/create_emprunt.html', {
                'membres': membre,
                'medias_disponibles': medias_disponibles
            })

        except ValueError:
            return HttpResponseBadRequest("L'identifiant du membres est invalide.")


class MediaViews(View):
    @admin_required
    @staticmethod
    def add_media(request):
        if request.method == 'POST':
            form = MediaForm(request.POST)
            if form.is_valid():
                media_type = form.cleaned_data['type']

                if media_type == 'livre':
                    specific_form = LivreForm(request.POST)
                elif media_type == 'cd':
                    specific_form = CDForm(request.POST)
                elif media_type == 'dvd':
                    specific_form = DVDForm(request.POST)
                elif media_type == 'jeu':
                    specific_form = JeuDePlateauForm(request.POST)
                else:
                    specific_form = None

                if specific_form and specific_form.is_valid():
                    media_instance = form.save(commit=False)
                    media_instance.type = media_type
                    media_instance.save()

                    specific_instance = specific_form.save(commit=False)
                    specific_instance.media = media_instance
                    specific_instance.save()

                    return redirect('list_medias')
                else:
                    # Afficher les erreurs du formulaire spécifique
                    print("Specific form errors:", specific_form.errors)
            else:
                # Afficher les erreurs du formulaire principal
                print("Main form errors:", form.errors)
        else:
            form = MediaForm()

        return render(request, 'bibliotheque/add_media.html', {'form': form})

    @admin_required
    @staticmethod
    def list_medias(request):
        livres = Livre.objects.filter(disponible=True)
        dvds = DVD.objects.filter(disponible=True)
        cds = CD.objects.filter(disponible=True)
        jeux_de_plateau = JeuDePlateau.objects.filter(disponible=True)

        medias = list(livres) + list(dvds) + list(cds) + list(jeux_de_plateau)
        media_types = {
            'Livre': livres,
            'DVD': dvds,
            'CD': cds,
            'Jeu de plateau': jeux_de_plateau
        }

        return render(request, 'bibliotheque/list_medias.html', {'medias': medias, 'media_types': media_types})

    @admin_required
    @staticmethod
    def return_emprunt(request, id):
        emprunt = get_object_or_404(Emprunt, pk=id)

        if request.method == 'POST':
            media = emprunt.media
            membre = emprunt.membre

            media.disponible = True
            media.save()
            membre.nb_emprunts -= 1
            membre.save()

            emprunt.delete()
            return redirect('list_emprunts')

        return render(request, 'bibliotheque/return_emprunt.html', {'emprunt': emprunt})

    @admin_required
    @staticmethod
    def list_emprunts(request):
        emprunts = Emprunt.objects.all()
        return render(request, 'bibliotheque/list_emprunts.html', {'emprunts': emprunts})

