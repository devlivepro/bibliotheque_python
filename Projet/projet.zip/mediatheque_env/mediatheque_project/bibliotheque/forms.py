from django import forms
from .models import Membre, Livre, CD, DVD, JeuDePlateau, Media

class MembreForm(forms.ModelForm):
    class Meta:
        model = Membre
        fields = ['nom', 'nb_emprunts', 'bloque']  # Inclure les champs nécessaires uniquement


class CreateEmpruntForm(forms.Form):
    media_id = forms.IntegerField(label='ID du média à emprunter')

    def clean_media_id(self):
        media_id = self.cleaned_data['media_id']
        media = Media.objects.filter(pk=media_id, disponible=True).first()

        if not media:
            raise forms.ValidationError("Ce média n'existe pas ou n'est pas disponible.")

        return media_id

class MediaForm(forms.ModelForm):
    class Meta:
        model = Media
        fields = ['type', 'titre', 'auteur', 'disponible']

class LivreForm(forms.ModelForm):
    class Meta:
        model = Livre
        fields = ['type', 'titre', 'auteur', 'disponible', 'nb_pages']

class CDForm(forms.ModelForm):
    class Meta:
        model = CD
        fields = ['type', 'titre', 'auteur', 'disponible', 'duree_minutes']

        def clean_duree_minutes(self):
            duree_minutes = self.cleaned_data.get('duree_minutes')

            if not duree_minutes:
                raise forms.ValidationError("Veuillez fournir la durée en minutes pour le CD.")

            return duree_minutes

class DVDForm(forms.ModelForm):
    class Meta:
        model = DVD
        fields = ['type', 'titre', 'auteur', 'disponible', 'duree_minutes']

class JeuDePlateauForm(forms.ModelForm):
    class Meta:
        model = JeuDePlateau
        fields = ['titre', 'createur', 'disponible']