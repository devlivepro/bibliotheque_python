from django.urls import path
from .views import MediaViews, index
from .views import MembreViews
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('list_medias/', MediaViews.list_medias, name='list_medias'),
    path('create_member/', MembreViews.create_member, name='create_member'),
    path('list_member/', MembreViews.list_member, name='list_member'),
    path('update_member/<int:membre_id>/', MembreViews.update_member, name='update_member'),
    path('confirm_delete_membre/<int:membre_id>/', MembreViews.confirm_delete_membre, name='confirm_delete_membre'),
    path('delete_membre/<int:membre_id>/', MembreViews.delete_membre, name='delete_membre'),
    path('create_emprunt/<int:membre_id>/', MembreViews.create_emprunt, name='create_emprunt'),
    path('list_medias/', MediaViews.list_medias, name='list_medias'),
    path('add_media/', MediaViews.add_media, name='add_media'),
    path('list_emprunts/', MediaViews.list_emprunts, name='list_emprunts'),

    path('return_emprunt/<int:id>/', MediaViews.return_emprunt, name='return_emprunt'),
]
