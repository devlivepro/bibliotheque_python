from django.shortcuts import render
from django.views import View

from bibliotheque.models import Livre, DVD, CD, JeuDePlateau

def index2(request):
    return render(request, 'membres/index.html')


class MediaViews(View):

    @staticmethod
    def consultation_medias(request):
        livres = Livre.objects.filter(disponible=True)
        dvds = DVD.objects.filter(disponible=True)
        cds = CD.objects.filter(disponible=True)
        jeux_de_plateau = JeuDePlateau.objects.filter(disponible=True)

        medias = list(livres) + list(dvds) + list(cds) + list(jeux_de_plateau)
        media_types = {
            'Livre': livres,
            'DVD': dvds,
            'CD': cds,
            'Jeu de plateau': jeux_de_plateau
        }

        return render(request, 'membres/consultation_medias.html', {'medias': medias, 'media_types': media_types})

